import json
from flask import Flask, request, jsonify, render_template
from joblib import load
import pandas as pd

app = Flask(__name__, static_url_path='/static')

# Load the trained model
model = load('model.pkl')
route_mapping = load('route_mapping.pkl')

@app.route('/')
def home():
    # Render the HTML interface
    return render_template('interface.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get input data from form submission
        route_name = request.form['value1']
        direction_id = request.form['value2']
        vehicle_id = request.form['value3']
        driver_id = request.form['value4']
        incident_category = request.form['value5']
        incident_type = request.form['value6']
        location = request.form['value7']   
        day = request.form['value8']
        month = request.form['value9']
        
        route_id = route_mapping[route_name]
        
        # Create DataFrame from input data
        input_data = pd.DataFrame({
            'route_id': [route_id],
            'direction_id': [direction_id],
            'vehicle_id': [vehicle_id],
            'driver_id': [driver_id],
            'incident_category': [incident_category],
            'incident_type': [incident_type],
            'location': [location],
            'day': [day],
            'month': [month]
        })

        # Make prediction using the loaded model
        prediction = model.predict(input_data)
        
        # Convert prediction to list
        result = {'prediction': prediction.tolist()}
        
        # Return result as JSON file
        with open('predictions.json', 'w') as file:
            json.dump(result, file)

    
        # Return the prediction as JSON response
        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=False)