# MDOT TSO - Traffic Pattern Impact on MTA On-Time Performance

**Contributors:** Salsabeel Abbasi, Gabriel Bekele, Dan Ouiya, Hassan Edwan, and Farhaan Lalit.

The Maryland Department of Transportation (MDOT) comprises five different business units and one authority, including the Maryland Transportation Administration which provides public transportation services across the state.

Ensuring the reliability and on-time performance of public transportation is a key concern for MDOT and MTA. In order to maintain efficient operations, MDOT is seeking to assess the impact of local traffic patterns on MTA on-time performance in different areas.

To aid with this, the student team from INST 490, at the University of Maryland, developed a predictive model to determine the impact on the schedule for all bus routes. Additionally, an in-depth analysis specific to the CityLink RED bus route was conducted.

This project was conducted in collaboration with Aviva Klugh of MDOT TSO and Cole Greene of MTA.


## Installation

To start with, clone this repository and set it as the working directory. The `requirements.txt` file lists the packages and dependencies used for this project. To install all Python related external packages, run `pip install -r requirements.txt` in your environment. Additionally, the frontend web interface has been developed using HTML, CSS and JavaScript.


## Project Structure

- `Data/`: A directory containing all the data for the predictive model.
    - `All_test.csv`: A CSV file containing 5 random rows that were removed from the resulting file after the bus stop data and RITIS events data were merged. This data is used for the sample predictions at the end of `Model_AllRoutes.ipynb` and demonstrating the functioning of the model.
    - `All.csv`: A CSV file containing the bus stop data and RITIS events data after merging.
    - `ritis-events-all.csv`: A CSV file downloaded from RITIS containing incident data from all over Maryland. This file was downloaded using the "Data Archive" on RITIS and selecting "All Maryland Data Sources" for all regions in Maryland from 10/01/2023 to 11/01/2023.
    - `Swiftly Bus Stop Data.csv`: A CSV file containing Bus Stop Data providing information on buses, routes, stops, schedule, drivers, vehicles, and their adherence to the schedule.
- `Frontend/`: A directory containing all the code for the frontend website.
    - `static/styles/styles.css`: A file containing CSS code for the styling of the website.
    - `templates/interface.html`: A file containing HTML code for the interface of the website. 
    - `app.py`: A file containing Python code for the functioning of the website. To open this website, change the working directory to `INST490_CAPSTONE/Frontend` and run `python app.py` in the terminal.
    - `model.pkl`: A pickle file containing the extracted predictive model used in the code for the frontend.
    - `predictions.json`: A JSON file containing the resulting prediction of the model that is created after using the frontend web interface.
    - `route_mapping.pkl`: A pickle file containing a dictionary of route mappings used in the frontend web interface.
- `Model/`: A directory containing all the code for the predictive model.
    - `Data_Prep_All.ipynb`: A Jupyter Notebook that contains the code for data preparation and cleaning.
    - `feature_analysis.ipynb`: A Jupyter Notebook that contains the code for feature analysis and determining the impact of various features on the target variable.
    - `Model_AllRoutes.ipynb`: A Jupyter Notebook that contains the code for data preprocessing and creation and training of the predictive model.